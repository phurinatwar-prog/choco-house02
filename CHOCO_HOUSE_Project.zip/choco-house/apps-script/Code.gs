/**
 * CHOCO HOUSE - Google Apps Script backend
 * 1) Create a Google Sheet, then Extensions > Apps Script.
 * 2) Paste this file. Run setup() once and authorize.
 * 3) Project Settings > Script Properties: set ADMIN_KEY to a strong secret.
 * 4) Deploy > New deployment > Web app; Execute as Me; access Anyone.
 * 5) Copy Web app URL into config.js as API_URL.
 */
const SHEET_NAME = "Orders";
const HEADERS = ["Order ID","Created At","Customer Name","Phone","Address","Note","Items JSON","Total","Status"];

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) sh.appendRow(HEADERS);
  sh.setFrozenRows(1);
  sh.getRange(1,1,1,HEADERS.length).setFontWeight("bold").setBackground("#ead8c4");
  PropertiesService.getScriptProperties().setProperty("SPREADSHEET_ID", ss.getId());
}

function doGet() {
  return json_({ok:true,service:"CHOCO HOUSE Orders API",message:"POST actions: createOrder, listOrders, updateStatus"});
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || "{}");
    if (body.action === "createOrder") return json_(createOrder_(body.order || {}));
    requireAdmin_(body.adminKey);
    if (body.action === "listOrders") return json_({ok:true,orders:listOrders_()});
    if (body.action === "updateStatus") return json_(updateStatus_(body.orderId,body.status));
    return json_({ok:false,error:"Unknown action"});
  } catch(err) {
    return json_({ok:false,error:String(err.message || err)});
  }
}

function createOrder_(o) {
  if (!o.customerName || !o.phone || !o.address || !Array.isArray(o.items) || !o.items.length) throw new Error("ข้อมูลคำสั่งซื้อไม่ครบ");
  if (String(o.customerName).length > 100 || String(o.address).length > 500) throw new Error("ข้อมูลยาวเกินกำหนด");
  const allowed = {"CHO-001":{name:"Milk Chocolate",price:59},"CHO-002":{name:"Dark Chocolate",price:69}};
  let total = 0;
  const cleanItems = o.items.map(i => {
    const p = allowed[i.sku], qty = Number(i.qty);
    if (!p || !Number.isInteger(qty) || qty < 1 || qty > 99) throw new Error("รายการสินค้าหรือจำนวนไม่ถูกต้อง");
    total += p.price * qty;
    return {sku:i.sku,name:p.name,qty:qty,unitPrice:p.price,lineTotal:p.price*qty};
  });
  const orderId = "CH" + Utilities.getUuid().replace(/-/g,"").slice(0,9).toUpperCase();
  const sh = sheet_();
  sh.appendRow([orderId,new Date(),String(o.customerName).trim(),String(o.phone).trim(),String(o.address).trim(),String(o.note||"").slice(0,200),JSON.stringify(cleanItems),total,"รอหยิบสินค้า"]);
  return {ok:true,orderId:orderId,total:total};
}

function listOrders_() {
  const sh=sheet_(), values=sh.getDataRange().getValues();
  if(values.length<2)return [];
  return values.slice(1).filter(r=>r[0]).reverse().map(r=>({
    orderId:String(r[0]),createdAt:r[1] instanceof Date?r[1].toISOString():String(r[1]),
    customerName:String(r[2]),phone:String(r[3]),address:String(r[4]),note:String(r[5]),
    items:JSON.parse(r[6]||"[]"),total:Number(r[7]),status:String(r[8])
  }));
}

function updateStatus_(orderId,status) {
  if(!orderId || !status || String(status).length>60)throw new Error("กรุณาระบุเลขออเดอร์และสถานะ");
  const sh=sheet_(), data=sh.getDataRange().getValues();
  for(let i=1;i<data.length;i++){if(String(data[i][0])===String(orderId)){sh.getRange(i+1,9).setValue(String(status));return {ok:true};}}
  throw new Error("ไม่พบคำสั่งซื้อ");
}
function requireAdmin_(key) {
  const expected=PropertiesService.getScriptProperties().getProperty("ADMIN_KEY");
  if(!expected)throw new Error("ผู้ดูแลยังไม่ได้ตั้งค่า ADMIN_KEY ใน Script Properties");
  if(!key || key!==expected)throw new Error("รหัสผู้ดูแลไม่ถูกต้อง");
}
function sheet_() {
  const id=PropertiesService.getScriptProperties().getProperty("SPREADSHEET_ID");
  if(!id)throw new Error("กรุณารัน setup() ก่อน");
  const ss=SpreadsheetApp.openById(id);
  let sh=ss.getSheetByName(SHEET_NAME);
  if(!sh){sh=ss.insertSheet(SHEET_NAME);sh.appendRow(HEADERS);}
  return sh;
}
function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
